## Implementation Tasks  

### Backend Setup Epic – Node.js/Express API  
- [ ] **Initialize project directories** – Create a new folder for the server, set up package.json and install required dependencies (`express`, `body-parser`). *Complexity: S*  
- [ ] **Implement in‑memory storage** – Define a simple JavaScript object to hold tasks (id, title, description). No persistent database needed. *Complexity: S*  

### Frontend Development Epic – Vue.js + Pinia Store & UI  
- [ ] **Set up Vue project** – Use Vite or Vue CLI to generate the frontend application structure. *Complexity: S*  
- [ ] **Configure Tailwind CSS** – Add Tailwind directives, purge file, and component support; ensure responsive design works. *Complexity: S*  
- [ ] **Create Pinia store** – Define `TaskStore` with actions `addTask`, `getTasks` and state to hold the task list. *Complexity: M*  

### Task Creation & Display UI  
- [ ] **Design task creation form** – Build a lightweight form component that captures title and description, validates input, and calls the Pinia store’s `addTask`. *Complexity: M*  
- [ ] **Render tasks list** – Create a responsive list view that fetches all tasks from the Pinia store and displays them using Tailwind styling. *Complexity: M*  

### Integration & Notifications  
- [ ] **Configure SendGrid API key** – Store the SendGrid configuration in environment variables; create helper to send email reminders when a task is created (optional future enhancement). *Complexity: L*  

### Deployment & Self‑Hosting Setup  
- [ ] **Generate server entry point** – Implement `app.js` with Express routes (`POST /tasks`, `GET /tasks`). Ensure CORS allows the frontend on localhost. *Complexity: M*  
- [ ] **Create systemd service (or equivalent)** – Write a script to start the Node server automatically at boot, suitable for self‑hosted deployment. *Complexity: L*  

### Final Validation & Cleanup  
- [ ] **Write unit tests** – Add basic Jest tests for Pinia store functions and API route handlers. *Complexity: M*  
- [ ] **Document setup steps** – Produce a short README covering folder structure, environment variables, and how to start both server and frontend locally. *Complexity: L*