# Architecture  

## 1. High‑Level System Overview  
The **SimpleTask Manager** is a client‑server application where the Vue.js front‑end communicates with a Node.js/Express back‑end via HTTP REST endpoints. The back‑end maintains an in‑memory array of tasks for demonstration purposes and can later be swapped to a persistent store. Email notifications are handled by an external SendGrid service; no authentication or complex security is required beyond input validation.

## 2. Technology Stack & Justification  

| Layer | Technology | Rationale |
|-------|------------|-----------|
| **Frontend** | Vue 3 + Pinia (state management) <br> Tailwind CSS (utility‑first styling) | Progressive‑framework with a clean API, excellent reactivity for UI updates. Pinia provides scoped stores without global state pollution. Tailwind delivers fast, responsive design with minimal CSS bloat. |
| **Backend** | Node.js + Express (RESTful API) <br> In‑memory storage (Array) | Node.js is lightweight and well‑suited for a single‑threaded demo. Express simplifies routing and middleware handling. An in‑memory store matches the self‑hosted, low‑resource deployment model. |
| **Database** | None (in‑memory) <br> Optional PostgreSQL later | For the initial version no DB is needed; persistence can be added without architectural change. |
| **Hosting / Deployment** | Self‑hosted Node.js server (local machine or VPS) | Keeps data and API completely under user control, aligning with “self‑hosted on my own server”. |
| **Frontend Hosting** | Self‑hosted Vue build (`npm run dev` or `serve`) | Directly runs from the backend directory; no external CDN required. |

## 3. Component Diagram Description  

The system consists of three logical components:  

1. **Vue App (Client)**  
   - `App.vue`: Root composition that renders the UI hierarchy.  
   - `TaskList.vue`: Displays a list of tasks; emits new tasks to parent via Pinia store.  
   - `NewTaskForm.vue`: Input fields for title and description, calls API on submit.  

2. **Express Server (API)**  
   - `routes/tasks.js`: GET `/tasks` → returns all tasks; POST `/tasks` → creates a new task.  
   - `middleware/validation.js`: Validates payload shape, prevents injection attacks.  

3. **Integration Layer**  
   - `notifications/sendGrid.js`: Sends email when a task is created (optional reminder).  

All components communicate via HTTP over the same origin (`http://localhost:8080`). The server serves static assets from its own public folder to reduce cross‑origin concerns.

## 4. Data Flow Description  

1. **Task Creation**  
   - User fills `NewTaskForm`, clicks *Create*.  
   - Form triggers a POST request to `/tasks` with JSON body `{title, description}`.  
   - Express validates payload → stores in‑memory array (indexed by ID).  
   - Server emits a response `{id, title, description}` back to the client.  

2. **Task List Rendering**  
   - `App.vue` subscribes to Pinia’s `tasks` store (populated via Express JSON endpoint `/tasks`).  
   - `TaskList.vue` iterates over stored tasks and displays them in a table.  

3. **Email Notification** *(optional)*  
   - After successful task creation, the server calls SendGrid API to send an email containing the new task details.  
   - The notification is asynchronous; no UI impact.  

4. **Error Handling**  
   - If validation fails or network request times out, error messages are shown in `TaskForm.vue`.  

## 5. Deployment Topology  

- **Backend Server**: Self‑hosted Node.js/Express instance on the user’s machine (or a VPS).  
- **Static Assets**: Served directly by Express (`app.use('/public', express.static('public'))`).  
- **Database**: None for this demo; data persists only in memory until server restart.  
- **Network**: Local HTTP service; no external routing needed.  

**Environment Variables (optional)**  
```env
NODE_ENV=development
SENDGRID_API_KEY=${SENDGRID_API_KEY}
```

## 6. Security Considerations  

1. **Input Validation & Sanitization**  
   - Express middleware (`express-validator`) checks that `title` and `description` are strings, preventing XSS via HTML injection.  

2. **CORS Restrictions**  
   - Allows only the same origin (`http://localhost:8080`) to access endpoints; no cross‑origin requests permitted.  

3. **Rate Limiting** (optional)  
   - Simple limit of 10 tasks per minute per IP to mitigate abuse.  

4. **Authentication Not Required** → No session or token handling, eliminating common attack surface.  

5. **Email Notification Security**  
   - SendGrid API key stored in environment variable; never logged or exposed.  
   - Use HTTPS when sending emails (SendGrid handles TLS).  

6. **Server Hardening**  
   - Run Node.js with least privileges, keep dependencies up‑to‑date (`npm audit`).  
   - Self‑hosted server does not expose the API publicly; only local network access allowed.  

7. **Data Integrity**  
   - Tasks are stored in memory; no persistent database means risk of data loss on restart is acceptable for this demo. For production, a lightweight SQLite or PostgreSQL DB would be recommended.