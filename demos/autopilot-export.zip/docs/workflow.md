# Development Workflow

## 1. Development Phases  

| Phase | Description |
|-------|-------------|
| **Initialization** | Set up the repo, database (if needed), and local server environment. Verify that Vue + Pinia, Node.js/Express, Tailwind CSS, and SendGrid can be accessed from within the VM. |
| **Feature Development** | Implement each feature on separate feature branches. <br>• `frontend` → Vue components, Pinia store, Tailwind utilities.<br>• `backend` → Express routes, data handling, email notification service integration. |
| **Integration Testing** | Merge front‑end and back‑end into a single branch (`dev`). Run end‑to‑end tests that cover task creation flow and email dispatch. |
| **QA & Validation** | Execute the QA checklist (see below). Fix any issues before moving to release. |
| **Release** | Freeze code, build final assets, and deploy to the self‑hosted server. Tag the commit with a version number. |

## 2. Branching Strategy  

- **Main branch** – `main` holds the production‑ready code.  
- **Feature branches** – Every new feature (frontend or backend) is created from `main`, named `feature/<short-description>`.  
- **Integration branch** – After all changes are merged, a temporary `dev` branch aggregates both front‑end and back‑end work for final testing.  
- **Release branch** – A short‑lived branch (`release/v1`) is created from `main`, tags the commit with a version tag (e.g., `v1.0.0`), and then merged back into `main`.  

No protection rules are required because the project is simple and self‑hosted.

## 3. CI/CD Pipeline Description  

```mermaid
flowchart TD
    A[Push to any branch] --> B{Run GitHub Actions}
    B --> C{lint & test}
    C --> D[Run integration tests]
    D --> E[Deploy to Docker container on server via SSH]
    E --> F[Notify Slack channel]
```

- **Linters / Type‑checkers** – `eslint` for JavaScript files, `prettier` for formatting.  
- **Tests** – Jest for unit tests (frontend & backend), Cypress for end‑to‑end UI flow.  
- **Build** – Vue CLI builds the static assets (`dist/`). The Node server is containerized with Docker.  
- **Deployment** – A GitHub Actions workflow pushes the Docker image to a private registry, then an SSH step copies the image to the user’s VPS and runs `docker compose up -d`.  

## 4. QA Checklist  

| # | Item | Acceptance Criteria |
|---|------|----------------------|
| 1 | **Task creation** – UI allows adding a task with title and description. | New task appears in the list immediately after submission. |
| 2 | **Data persistence** – Data survives page refresh. | Reloading the page shows the same tasks without loss. |
| 3 | **Email notification** – System sends email to user (simulated via SendGrid) when a new task is created. | Email body contains task title, timestamp, and link to app. |
| 4 | **Responsive layout** – UI adapts to mobile widths ≤ 768px. | Elements remain readable; no horizontal overflow. |
| 5 | **Error handling** – Empty fields show validation messages. | “Title cannot be empty” appears when title is blank. |
| 6 | **Docker health** – Container starts correctly after deployment. | `docker ps` shows the app as healthy (`healthy`). |

## 5. Release Process  

1. **Tagging** – When all QA items pass, create a Git tag (e.g., `v0.1.0`).  
2. **CI/CD** – The GitHub Actions workflow automatically builds the Docker image and updates the server’s container via SSH.  
3. **Verification** – A post‑deployment smoke test runs (`curl` + UI check) to confirm the new version is live.  
4. **Notification** – Slack message sent to `#release-updates` with tag number and a link to the Docker image registry.  
5. **Rollback plan** – If the new release fails, revert by pulling the previous tag’s image (`docker pull <registry>/simple-task-manager:<previous-tag>`) and redeploying it.