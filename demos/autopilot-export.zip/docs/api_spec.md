# API Specification

## Endpoints

### Create Task  
- **Method:** `POST`  
- **Path:** `/api/tasks`  
- **Authentication:** None (no auth required)  
- **Request Body:**  
  ```json
  {
    "title": "string",
    "description": "string"
  }
  ```  
- **Response (201 Created):**  
  ```json
  {
    "id": number,
    "title": string,
    "description": string,
    "createdAt": "ISOString"
  }
  ```  
- **Error Responses:**  
  - `400 Bad Request` – required fields (`title`, `description`) missing or empty.  

### List Tasks  
- **Method:** `GET`  
- **Path:** `/api/tasks`  
- **Authentication:** None (no auth required)  
- **Response (200 OK):**  
  ```json
  [
    {
      "id": number,
      "title": string,
      "description": string,
      "createdAt": "ISOString"
    },
    ...
  ]
  ```  

### Delete Task *(optional)*  
- **Method:** `DELETE`  
- **Path:** `/api/tasks/{id}`  
- **Authentication:** None (no auth required)  
- **Response (204 No Content)** on success; `404 Not Found` if the task does not exist.  

## Rate Limiting Considerations  
- The API will enforce a minimum rate limit of **10 requests per second** per client IP/user‑agent to protect server performance.  
- If the application scales, limits can be adjusted; higher concurrency is anticipated only during development.