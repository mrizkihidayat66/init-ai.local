### System Architecture

High-level system overview for SimpleTask Manager

```mermaid
flowchart TD
    node_n_user(["User"])
    node_n_app["SimpleTask Manager"]
    node_n_db[("Database")]
    node_n_user -->|interacts| node_n_app
    node_n_app -->|reads/writes| node_n_db
```

### Entity Relationship

Core data model

```mermaid
erDiagram
    entity_e_user["User"] {
        string id PK
        string email UK
    }
    entity_e_item["Item"] {
        string id PK
        string userId FK
    }
    entity_e_user ||--o{ entity_e_item : "owns"
```

### User Flow

Primary user journey

```mermaid
flowchart TD
    node_f_start(("Start"))
    node_f_main["Main Action"]
    node_f_end(("Done"))
    node_f_start --> node_f_main
    node_f_main -->|complete| node_f_end
```

### Key Sequence

Primary request/response interaction

```mermaid
sequenceDiagram
    actor participant_p_user as User
    participant participant_p_app as Application
    participant participant_p_db as Database
    participant_p_user->>participant_p_app: Request
    participant_p_app->>participant_p_db: Query
    participant_p_db-->>participant_p_app: Result
    participant_p_app-->>participant_p_user: Response
```