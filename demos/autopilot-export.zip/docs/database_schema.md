## Database Overview

Database schema for SimpleTask Manager. [Fallback placeholder — regenerate for accurate schema]

## Entities

### User

Application user accounts

Fields:
- id: string (PK)
- email: string (UK)
- createdAt: datetime
Indexes:
- email

### Session

User authentication sessions

Fields:
- id: string (PK)
- userId: string (FK)
- expiresAt: datetime
Indexes:
- userId

### Resource

Core application resource

Fields:
- id: string (PK)
- userId: string (FK)
- createdAt: datetime
Indexes:
- userId

## Relationships

- t_user -> t_session: has
- t_user -> t_resource: owns

## Constraints

- Users must have unique email addresses

## Entity Relationship Diagram

```mermaid
erDiagram
    entity_t_user["User"] {
        string id PK
        string email UK
        datetime createdAt
    }
    entity_t_session["Session"] {
        string id PK
        string userId FK
        datetime expiresAt
    }
    entity_t_resource["Resource"] {
        string id PK
        string userId FK
        datetime createdAt
    }
    entity_t_user ||--o{ entity_t_session : "has"
    entity_t_user ||--o{ entity_t_resource : "owns"
```