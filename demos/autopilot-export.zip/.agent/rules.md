# Agent Rules

## Coding Standards and Conventions  
- **Vue components** follow the single‑responsibility principle; use the composition API only.  
- **Pinia stores** must be immutable—store mutations go through actions; getters compute derived state.  
- **Tailwind CSS** is used in a utility‑first manner; all classes are valid and subject to purge configuration.  
- Naming conventions: component files end with `.vue`, store files end with `.ts` (camelCase), API endpoints end with `/api`.

## File Naming and Structure  
```
src/
├── components/
│   └── TaskList.vue
├── store/
│   └── tasks.ts          # Pinia store definition
├── api/
│   ├── tasks.ts         # HTTP wrapper using Express
│   └── sendgrid.ts      # Email notification helper
└── main.ts
```

## Git Commit Message Format  
```
<type>(<scope>): <short description>

<body>
- Why this change?
- What does it do?
- How to test?
```
* `type` = `feat`, `fix`, `docs`, `style`, `refactor`.  
* Keep the subject under 50 characters.  

## Testing Requirements  
- **Unit tests**: Pinia store logic (Jest) ≥ 80 % coverage.  
- **Integration test**: Express route + SendGrid payload verification.  
- All critical paths must be covered by at least one test.  
- CI pipeline runs `npm test` on every push.

## Code Review Checklist  
- ✅ Vue component is self‑contained and uses composition API correctly.  
- ✅ Pinia store exports only necessary actions/computed properties.  
- ✅ Express server includes body parser middleware before async routes.  
- ✅ SendGrid key stored in `.env`; no secrets in version control.  
- ✅ All Tailwind classes are valid and purged by build script.  
- ✅ Commit message follows the format above.  

## Technology‑Specific Best Practices  
- **Vue + Pinia**: Keep store state separate from components; avoid global singletons.  
- **Node.js / Express**: Use `async/await` with proper error handling for API routes.  
- **SendGrid integration**: Wrap email sending in a promise to allow async queue.  
- **Self‑hosted deployment**: Ensure environment variables are loaded from `.env`.